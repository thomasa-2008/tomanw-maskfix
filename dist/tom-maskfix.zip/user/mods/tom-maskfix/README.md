# tomanw-maskfix
Allows you to put the Skull Mask in your eyewear slot.
